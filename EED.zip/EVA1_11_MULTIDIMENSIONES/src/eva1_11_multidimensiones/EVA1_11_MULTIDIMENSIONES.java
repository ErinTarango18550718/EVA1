/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_11_multidimensiones;

/**
 *
 * @author Leslie Johana Peña Hernandez 18550680
 */
public class EVA1_11_MULTIDIMENSIONES {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //ARREGLO DE DOS DIMENSIONES --->MATRIZ
      int aDatos[][] = new int [3][4];
        System.out.println("direccion del arreglo" + aDatos);
        System.out.println("tamaño del arreglo " + aDatos.length);
        
         System.out.println("direccion del arreglo aDatos[0]" + aDatos[0]);
                 System.out.println("tamaño del arreglo aDatos[0] " + aDatos[0].length);
  
          System.out.println("valor de la posicion de aDatos[0][0]" + aDatos[0][0]);
          System.out.println("tamaño del arreglo aDatos[0] " + aDatos[0].length);

                 
    }
    
}
