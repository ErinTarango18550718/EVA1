/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_8_copia_arreglos;

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aiDatos[] = new int[10];
        int aiCopia[] = new int[10];
        for (int i = 0; i < aiDatos.length; i++) {
            aiDatos[i] = (int)(Math.random() * 100)+ 1;
            
        }
        
        for (int i = 0; i < aiDatos.length; i++) {
               aiCopia[i] = (int)(Math.random() * 100)+ 1;
        }
               imprimirarreglo(aiDatos);
               imprimirarreglo(aiCopia);
        System.out.println(aiDatos);
        System.out.println(aiCopia);
               
    }
    public static void imprimirarreglo(int[] args){
        
        System.out.println("");
        for (int i = 0; i < args.length; i++) {
               System.out.print("[" + args[i] + "]");
    }
        System.out.println("");
}
}
